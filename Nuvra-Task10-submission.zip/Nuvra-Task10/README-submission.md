# Nuvra

A company website with customer accounts, service management, and staff workspaces.

## Tools

- **Frontend:** React, TypeScript, Vite, CSS
- **Backend:** Node.js, Express
- **Database:** Neon PostgreSQL; SQLite for local development
- **File storage:** Multer with local files; private Vercel Blob for production
- **Hosting:** Vercel
- **Checks:** TypeScript, Oxlint, Node test runner with tsx

## Completed tasks

### Task 1 — Company Landing Page

A responsive company website introduces Nuvra, its tools, and company information. Desktop and mobile navigation help visitors browse the page sections.

### Task 2 — Contact & Inquiry System

Visitors can submit their name, email, subject, and message through the contact form. The backend validates submissions and stores valid inquiries in the database, while the form shows success or error feedback.

### Task 3 — Internal Content Management

Administrators can add, view, edit, and delete Tools, Clients, and Subscriptions. Records are loaded from and saved to the database, with validation for duplicate records and linked subscriptions.

### Task 4 — User Registration & Authentication

Users can register, log in, and log out. Backend validation, password hashing, and session-based authentication protect accounts and restrict access to protected features.

### Task 5 — Customer Dashboard

Each customer has a protected dashboard showing their own account information from the database. Customers can update their name and email, with changes saved for future visits.

### Task 6 — Service Management

Administrators can create, update, and delete company services, labelled **Tools**. The public website loads these services from the backend and displays saved changes on the next page load or refresh.

### Task 7 — Customer Request Management

Customers can submit requests and view their own request history and progress. Employees and administrators can review requests and update their status to **Pending**, **In progress**, **Completed**, or **Cancelled**; customers see updates after refreshing.

### Task 8 — Search & Filtering

Administrators can search Tools, Clients, Subscriptions, and Requests. Request searches combine keywords, status, and submission dates, with results retrieved from the backend; customers can search only their own requests.

### Task 9 — Role-Based Access

Three roles have different permissions enforced by the backend:

- **Administrator:** manages company records and all customer requests.
- **Regular Employee:** views and searches all requests and updates their status, but cannot manage Tools, Clients, or Subscriptions.
- **Customer:** views and edits their own profile, submits requests, and tracks their own request progress.

Admin and Employee workspaces use distinct colours and display the signed-in role, name, and email for easy identification.

### Task 10 — File & Document Management

My Space keeps its main container and switches between **My Requests** and **My Documents** using internal tabs. Customers can select, upload, list, and delete their own PDF, DOC, DOCX, and TXT files up to 10 MB. The page displays file details and validation, loading, success, and error feedback.

`POST /api/documents`, `GET /api/documents`, and `DELETE /api/documents/:id` use the existing authenticated session. The backend assigns ownership; frontend `user_id` values cannot grant access to another user's documents. Local development uses Multer, SQLite metadata, and files in `uploads/documents/`. Production support uses PostgreSQL/Neon metadata and private Vercel Blob direct upload, with a signed completion callback.

To check locally, sign in as a customer and open **My space → My Documents**. Upload a supported file, confirm it appears, refresh the page, then delete it and confirm it disappears. Check missing files, unsupported formats, files over 10 MB, and isolation between two accounts. Storage and database errors are displayed when applicable.

Isolated local API checks passed for session protection, upload/list/delete, database persistence, ownership isolation, invalid submissions, and physical file cleanup. PDF/DOC/DOCX checks used signature fixtures; full document compatibility and browser refresh/tab feedback still require manual verification. Production wiring was reviewed without live Neon/Blob tests; deployment testing is not required for Task 10 acceptance.

The frontend defaults to local upload in development and Blob upload in a production build; `VITE_DOCUMENT_UPLOAD_MODE=local` or `blob` overrides this when needed. Deployment support requires a private Blob store and server-side `BLOB_READ_WRITE_TOKEN`; `BLOB_UPLOAD_CALLBACK_URL` optionally overrides the HTTPS completion URL. No production storage credentials are needed for local SQLite testing.

## Run locally

Use Node.js 24 LTS. Extract the project and open a terminal in its folder.

Install dependencies once:

```sh
npm ci
```

Start the backend:

```sh
npm run server
```

In a second terminal, start the frontend:

```sh
npm run dev
```

Open the local URL shown by Vite (usually `http://localhost:5173`). Keep both terminals running.

Local testing uses SQLite when `DATABASE_URL` is unset; no Neon connection is required. A fresh local database has no login accounts, so register the test accounts below before signing in. Existing online accounts are not copied automatically.

## Administrator access

Open `/admin` and sign in with an administrator account.

- **Administrator email:** `admin1234@gmail.com`
- **Administrator password:** `test12345678`

For a new local database, register an account using these details, then run the following in another terminal in the project folder:

```sh
npm run admin:promote -- admin1234@gmail.com
```

Sign out and sign in again after assigning the role.

## Customer access

Register an account, then log in and select **My space** to open your dashboard.

## Employee access

Open `/employee` and sign in with an employee account.

- **Employee email:** employee@example.com
- **Employee password:** test12345678

For a new local database, register an account using these details, then run the following in another terminal in the project folder:

```sh
npm run employee:grant -- employee@example.com
```

Sign out and sign in again after assigning the role.

Module details: [Frontend](src/README.md) · [Backend](server/README.md) · [Shared](shared/README.md) · [Tests](tests/README.md).
